# Sacum - Passeggiata Virtuale

## Come pubblicare su GitHub Pages
1. Vai su [GitHub](https://github.com) e crea un nuovo repository pubblico chiamato `sacum`.
2. Clicca "Add file" → "Upload files" e carica tutti i file di questa cartella.
3. Vai su "Settings" → "Pages".
4. In "Build and deployment", scegli `Deploy from a branch`.
5. In "Branch" seleziona `main` e cartella `/root` → salva.
6. Dopo pochi minuti il sito sarà disponibile su `https://TuoNome.github.io/sacum`.
