function loadCity(city) {
    const cityData = {
        londra: { img: 'assets/londra.jpg', desc: 'Passeggiata virtuale a Londra.' },
        newyork: { img: 'assets/newyork.jpg', desc: 'Passeggiata virtuale a New York.' },
        parigi: { img: 'assets/parigi.jpg', desc: 'Passeggiata virtuale a Parigi.' }
    };
    if (cityData[city]) {
        document.getElementById('city-view').innerHTML = 
            `<h2>${city}</h2><p>${cityData[city].desc}</p><img src="${cityData[city].img}" alt="${city}">`;
    }
}
